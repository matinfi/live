<?php get_header(); ?>
<main id="main" class="chat-app" aria-labelledby="chat-title">
	<aside class="chat-sidebar" aria-label="کنترل‌های گفتگو">
		<a class="chat-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="brand-mark" aria-hidden="true">م</span> ماتین <i>AI</i></a>
		<button id="new-chat" class="new-chat" type="button"><span aria-hidden="true">＋</span> گفت‌وگوی جدید</button>
		<label class="sidebar-search"><span class="sr-only">جست‌وجوی سریع</span><input id="sidebar-search" type="search" placeholder="جست‌وجوی سریع"></label>
		<nav class="sidebar-section sidebar-nav" aria-label="کشف تجربه‌ها"><p>کشف تجربه‌ها</p><button class="starter" type="button" data-prompt="کافه‌های مناسب برای قرار را پیشنهاد بده">کشف کافه‌ها</button><button class="starter" type="button" data-prompt="امشب کجا موسیقی زنده دارد؟">موسیقی زنده</button><button class="starter" type="button" data-prompt="کدام کافه امشب بازی فوتبال را پخش می‌کند؟">پخش فوتبال</button><button class="starter" type="button" data-prompt="چه برنامه‌هایی این هفته برگزار می‌شوند؟">رویدادهای پیش‌رو</button><button class="starter" id="near-me" type="button">کافه‌های نزدیک من</button></nav>
		<p class="sidebar-note">ماتین فقط کافه‌ها و ایونت‌های ثبت‌شده در همین سایت را پیشنهاد می‌دهد.</p>
		<?php
		$base = home_url( '/my-account/' );
		if ( is_user_logged_in() ) :
			$me   = wp_get_current_user();
			$name = $me->display_name ?: $me->user_login;
			?>
		<nav class="sidebar-section sidebar-nav account-menu" aria-label="حساب کاربری"><p>حساب من</p>
			<details class="user-menu">
				<summary class="starter"><span class="account-initial" aria-hidden="true"><?php echo esc_html( mb_substr( $name, 0, 1, 'UTF-8' ) ); ?></span><span><?php echo esc_html( $name ); ?></span></summary>
				<a class="starter account-link" href="<?php echo esc_url( add_query_arg( [ 'matin_tab' => 'reservations', 'status' => 'pending' ], $base ) ); ?>">⏳ در انتظار تأیید</a>
				<a class="starter account-link" href="<?php echo esc_url( add_query_arg( [ 'matin_tab' => 'reservations', 'status' => 'confirmed' ], $base ) ); ?>">✅ تأییدشده</a>
				<a class="starter account-link" href="<?php echo esc_url( add_query_arg( [ 'matin_tab' => 'reservations', 'status' => 'cancelled' ], $base ) ); ?>">🚫 لغوشده</a>
				<a class="starter account-link" href="<?php echo esc_url( add_query_arg( [ 'matin_tab' => 'reservations', 'status' => 'all' ], $base ) ); ?>">🎟 همه بلیت‌ها</a>
				<a class="starter account-link" href="<?php echo esc_url( add_query_arg( 'matin_tab', 'settings', $base ) ); ?>">⚙ تنظیمات حساب</a>
				<a class="starter account-link" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">↩ خروج</a>
			</details>
		</nav>
		<?php else : ?>
		<nav class="sidebar-section sidebar-nav" aria-label="حساب کاربری"><p>حساب من</p><a class="starter account-link" href="<?php echo esc_url( $base ); ?>">🎟 ورود / ساخت حساب</a></nav>
		<?php endif; ?>
		<div class="sidebar-account"><span class="account-initial" aria-hidden="true">م</span><span><b>Matin AI</b><small>کشف و رزرو کافه</small></span></div>
	</aside>
	<section class="chat-main">
		<header class="chat-topbar"><div><p class="status-dot">راهنمای رزرو</p><h1 id="chat-title">گفت‌وگوی جدید</h1></div><div class="top-actions"><button id="new-chat-top" class="top-new-chat" type="button">گفت‌وگوی جدید</button><button id="mobile-menu" class="icon-button" type="button" aria-label="باز کردن منو" aria-expanded="false">☰</button></div></header>
		<div id="conversation" class="conversation" aria-live="polite" aria-label="گفتگو با ماتین">
			<section class="welcome-message"><div class="ai-avatar" aria-hidden="true">م</div><div><p class="message-label">ماتین AI · راهنمای رزرو</p><h2>امشب دنبال چه تجربه‌ای هستی؟</h2><p>زمان، محله و تعداد نفرات را بنویسید؛ من فقط از میان کافه‌ها و ایونت‌های ثبت‌شده، گزینه‌های قابل‌درخواست را نشان می‌دهم.</p><div class="welcome-chips"><button class="starter" type="button" data-prompt="امشب کجا موسیقی زنده دارد؟">موسیقی زنده امشب</button><button class="starter" type="button" data-prompt="کدام کافه امشب بازی فوتبال را پخش می‌کند؟">پخش فوتبال</button><button class="starter" type="button" data-prompt="برای فردا شب یک میز برای دو نفر پیدا کن">رزرو میز برای دو نفر</button><button class="starter" type="button" data-prompt="برنامه‌های آخر هفته را نشان بده">برنامه‌های آخر هفته</button></div></div></section>
		</div>
		<div class="composer-wrap"><form id="assistant-form" class="composer"><label class="sr-only" for="assistant-prompt">پیام شما برای ماتین</label><textarea id="assistant-prompt" name="prompt" rows="1" maxlength="500" placeholder="مثلاً: برای فردا شب یک میز برای دو نفر در مرکز شهر پیدا کن"></textarea><button class="send-button" type="submit" aria-label="ارسال پیام"><span aria-hidden="true">↑</span></button></form><p>Enter برای ارسال و Shift + Enter برای خط جدید. درخواست رزرو پس از بررسی میزبان تأیید می‌شود.</p></div>
	</section>
</main>
<dialog id="reservation-dialog" aria-labelledby="reservation-title"><button class="dialog-close" type="button" aria-label="بستن">×</button><p class="eyebrow">درخواست رزرو</p><h2 id="reservation-title">رزرو رویداد</h2><p id="reservation-event"></p><form id="reservation-form"><input type="hidden" name="eventId"><label>نام و نام خانوادگی<input name="name" required minlength="4" autocomplete="name"></label><label>ایمیل (اختیاری)<input name="email" type="email" autocomplete="email"></label><label>شماره تماس<input name="phone" required minlength="8" inputmode="tel" autocomplete="tel"></label><label>تعداد نفرات<input name="guests" type="number" value="1" min="1" max="20" required></label><input name="website" class="honeypot" tabindex="-1" autocomplete="off"><button class="button" type="submit">ثبت درخواست</button><p id="reservation-message" aria-live="polite"></p></form></dialog>
<?php get_footer();
